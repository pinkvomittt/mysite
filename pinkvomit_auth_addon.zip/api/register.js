export default async function handler(req, res) {
  const SUPABASE_URL = "https://legghxaprgxcxbskvhgh.supabase.co";
  const SUPABASE_KEY = "eyJhbGciOiJlUz| 1NilsInR5cCI6lkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZil6ImxIZ2doeGFwcmd4Y3hic212aGdoliwicm9sZSI6ImFub24iLCJpYXQiOjEЗNDkyNjQ2Nzks|mV4cCI6MjA2NDg0MDY3OX0.d8T2APt1hvpgiFS4l_z0_LAOo3-XKQOy95s_XxSaLw";

  if (req.method === 'POST') {
    const { username, password } = req.body;
    const response = await fetch(`${SUPABASE_URL}/auth/v1/signup`, {
      method: 'POST',
      headers: {
        'apikey': SUPABASE_KEY,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ email: username, password })
    });

    const data = await response.json();
    res.status(200).json(data);
  } else {
    res.status(405).send("Method Not Allowed");
  }
};